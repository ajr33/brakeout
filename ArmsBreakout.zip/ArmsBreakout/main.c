extern void brakeout(void);

/**
 * main.c
 */
int main(void)
{
    brakeout();
	return 0;
}
